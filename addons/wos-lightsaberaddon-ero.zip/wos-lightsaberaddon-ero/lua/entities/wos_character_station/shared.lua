ENT.Type 		= "anim"
ENT.PrintName	= "Skill Station"
ENT.Author		= "King David"
ENT.Contact		= ""
ENT.Category = "wiltOS Technologies"
ENT.Spawnable			= true
ENT.AdminSpawnable		= true

